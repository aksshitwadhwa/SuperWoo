(function ($) {
    'use strict';

    // Optimizers and Elementor preview transitions can evaluate the same
    // bundle more than once. Only one instance may own cart event handlers.
    if (window.__superwooCartDrawerInitialized) {
        return;
    }
    window.__superwooCartDrawerInitialized = true;

    var lastFocus = null;
    var triggerObserver = null;
    var triggerSyncTimer = null;
    var stickyBuyNowTimer = null;
    var productCartVisibilityObserver = null;
    var observedProductCartForm = null;
    var productQuantityObserver = null;
    var productQuantityNormalizeTimer = null;
    var storeApiNonce = '';
    var currentOfferState = window.SuperWooCart && SuperWooCart.offerState ? SuperWooCart.offerState : { discounts: {}, gifts: {} };
    var productAddInFlight = false;
    var lastProductAddKey = '';
    var lastProductAddAt = 0;
    var applyingOwnCartFragments = false;

    function shell() {
        return $('[data-superwoo-cart-shell]').first();
    }

    function drawer() {
        return shell().find('.superwoo-cart-drawer').first();
    }

    function isDashboardUrl() {
        var path = window.location && window.location.pathname ? window.location.pathname.toLowerCase() : '';

        path = path.replace(/^\/+|\/+$/g, '');

        return path === 'dashboard' || path.indexOf('dashboard/') === 0 || path.indexOf('/dashboard/') !== -1;
    }

    function suppressDashboardBottomNav() {
        if (!(window.SuperWooCart && SuperWooCart.dashboardPage) && !isDashboardUrl()) {
            return false;
        }

        $('body')
            .addClass('superwoo-dashboard-page')
            .removeClass('superwoo-has-mobile-bottom-nav superwoo-mobile-search-open');

        $('[data-superwoo-mobile-bottom-nav], .superwoo-mobile-bottom-nav, [data-superwoo-mobile-search-sheet], .superwoo-mobile-search-sheet').remove();

        return true;
    }

    function announce(message) {
        shell().find('.superwoo-cart-live').text(message || '');
    }

    function showCartError(message) {
        shell().find('[data-superwoo-cart-error]')
            .text(message || '')
            .prop('hidden', !message);
    }

    function offerStateItems(state, type) {
        return state && state[type] ? state[type] : {};
    }

    function firstNewOfferMessage(previousState, nextState) {
        var types = ['gifts', 'discounts'];
        var found = '';

        $.each(types, function (_index, type) {
            var previousItems = offerStateItems(previousState, type);
            var nextItems = offerStateItems(nextState, type);

            $.each(nextItems, function (key, item) {
                if (!previousItems[key] && item && item.message) {
                    found = item.message;
                    return false;
                }
            });

            return !found;
        });

        return found;
    }

    function showOfferEvents(events) {
        var i;

        if (!$.isArray(events)) {
            return false;
        }

        for (i = 0; i < events.length; i += 1) {
            if (events[i] && events[i].message) {
                return true;
            }
        }

        return false;
    }

    function syncOfferState(nextState, suppressToast) {
        var message;

        if (!nextState) {
            return;
        }

        message = firstNewOfferMessage(currentOfferState, nextState);
        currentOfferState = nextState;

        if (window.SuperWooCart) {
            SuperWooCart.offerState = nextState;
        }

        return !!message && !suppressToast;
    }

    function scrollContainer() {
        return shell().find('[data-superwoo-cart-scroll]').first();
    }

    function resolvedHash(element) {
        var href = $(element).attr('href') || '';

        if (!href) {
            return '';
        }

        if (href.charAt(0) === '#') {
            return href;
        }

        try {
            return new URL(href, window.location.href).hash;
        } catch (error) {
            return /#superwoo-cart(?:$|[?&])/.test(href) ? '#superwoo-cart' : '';
        }
    }

    function isCartTriggerLink(element) {
        return $(element).is('[data-superwoo-cart-trigger], [data-superwoo-open-cart]') || resolvedHash(element) === '#superwoo-cart';
    }

    function closestCartTrigger(target) {
        if (!target || target === document) {
            return null;
        }

        if (target.closest) {
            return target.closest('a[href="#superwoo-cart"], a[href$="#superwoo-cart"], [data-superwoo-cart-trigger], [data-superwoo-open-cart]');
        }

        return $(target).closest('a[href], [data-superwoo-cart-trigger], [data-superwoo-open-cart]').get(0);
    }

    function currentCartCount() {
        var count = parseInt(window.SuperWooCart && SuperWooCart.cartCount, 10);

        if (isNaN(count)) {
            count = parseInt($('.superwoo-cart-drawer__header .superwoo-cart-count, .superwoo-cart-button .superwoo-cart-count, .superwoo-elementor-cart-count').first().text(), 10);
        }

        return isNaN(count) ? 0 : count;
    }

    function setCartCount(count) {
        var nextCount = parseInt(count, 10);

        if (isNaN(nextCount)) {
            nextCount = 0;
        }

        if (window.SuperWooCart) {
            SuperWooCart.cartCount = nextCount;
        }
        $('.superwoo-cart-count').text(nextCount);
    }

    function cartTriggerLinks() {
        return $('a[href], [data-superwoo-cart-trigger]').filter(function () {
            return isCartTriggerLink(this);
        });
    }

    function cartTriggerIcon() {
        var icon = window.SuperWooCart && SuperWooCart.headerCartIcon ? SuperWooCart.headerCartIcon : 'outline-bag';
        if (icon === 'filled-bag') {
            return '<svg class="superwoo-elementor-cart-icon" viewBox="0 0 32 32" aria-hidden="true" focusable="false"><path class="superwoo-cart-icon-fill" d="M8 12h16l3 17H5l3-17Z"/><path d="M11 12V9a5 5 0 0 1 10 0v3"/></svg>';
        }
        if (icon === 'basket') {
            return '<svg class="superwoo-elementor-cart-icon" viewBox="0 0 32 32" aria-hidden="true" focusable="false"><path d="M5 13h22l-2 15H7L5 13Z"/><path d="m9 13 3-7m11 7-3-7M4 13h24"/></svg>';
        }
        return '<svg class="superwoo-elementor-cart-icon" viewBox="0 0 32 32" aria-hidden="true" focusable="false"><path d="M7 12h18l2 17H5L7 12Z"/><path d="M11 12V9a5 5 0 0 1 10 0v3"/></svg>';
    }

    function syncCartTriggerBadges() {
        cartTriggerLinks().each(function () {
            var $trigger = $(this);
            var label = (window.SuperWooCart && SuperWooCart.i18n && SuperWooCart.i18n.cartItems) ? SuperWooCart.i18n.cartItems : 'Cart items';
            var $icon = $trigger.children('.elementor-icon').first();

            $trigger.addClass('superwoo-elementor-cart-trigger');

            if (!$trigger.find('.superwoo-elementor-cart-icon').length) {
                if ($icon.length) {
                    $icon.empty().append(cartTriggerIcon());
                } else {
                    $trigger.prepend(cartTriggerIcon());
                }
            }

            $trigger.children('.superwoo-cart-count:not(.superwoo-elementor-cart-count)').remove();

            if (!$trigger.children('.superwoo-elementor-cart-count').length) {
                $trigger.append('<span class="superwoo-cart-count superwoo-elementor-cart-count" aria-label="' + label + '">0</span>');
            }
        });

        setCartCount(currentCartCount());
    }

    function scheduleTriggerSync() {
        window.clearTimeout(triggerSyncTimer);
        triggerSyncTimer = window.setTimeout(syncCartTriggerBadges, 50);
    }

    function startTriggerObserver() {
        if (triggerObserver || !window.MutationObserver || !document.body) {
            return;
        }

        triggerObserver = new MutationObserver(scheduleTriggerSync);
        triggerObserver.observe(document.body, {
            attributes: true,
            attributeFilter: ['href', 'data-superwoo-cart-trigger'],
            childList: true,
            subtree: true
        });
    }

    function fetchCartCount() {
        if (!window.SuperWooCart || !SuperWooCart.cartApiUrl || !window.fetch) {
            return;
        }

        window.fetch(SuperWooCart.cartApiUrl, {
            credentials: 'same-origin'
        })
            .then(function (response) {
                captureStoreApiTokens(response);
                return response.ok ? response.json() : null;
            })
            .then(function (cart) {
                if (cart && typeof cart.items_count !== 'undefined') {
                    setCartCount(cart.items_count);
                }
            })
            .catch(function () {});
    }

    function captureStoreApiTokens(response) {
        if (!response || !response.headers) {
            return;
        }

        storeApiNonce = response.headers.get('Nonce') || storeApiNonce;
    }

    function refreshDrawerAfterStoreApiChange() {
        return post('superwoo_refresh_cart_drawer', {}, null, {
            refreshWooFragments: true
        });
    }

    function mutateWooCommerceCart(endpoint, payload) {
        var headers = {
            'Content-Type': 'application/json'
        };

        if (!window.SuperWooCart || !SuperWooCart.cartApiUrl || !window.fetch) {
            return $.Deferred().reject().promise();
        }

        if (!storeApiNonce) {
            return $.Deferred(function (deferred) {
                window.fetch(SuperWooCart.cartApiUrl, { credentials: 'same-origin' })
                    .then(function (response) {
                        captureStoreApiTokens(response);
                        if (!response.ok || !storeApiNonce) {
                            throw new Error('WooCommerce cart session is unavailable.');
                        }
                        return mutateWooCommerceCart(endpoint, payload);
                    })
                    .then(deferred.resolve)
                    .catch(deferred.reject);
            }).promise();
        }

        if (storeApiNonce) {
            headers.Nonce = storeApiNonce;
        }

        return $.Deferred(function (deferred) {
            window.fetch(SuperWooCart.cartApiUrl + '/' + endpoint, {
                method: 'POST',
                credentials: 'same-origin',
                headers: headers,
                body: JSON.stringify(payload)
            })
                .then(function (response) {
                    captureStoreApiTokens(response);
                    if (!response.ok) {
                        throw new Error('WooCommerce cart update failed.');
                    }
                    return response.json();
                })
                .then(deferred.resolve)
                .catch(deferred.reject);
        }).promise();
    }

    function moveCrossSellByCard(row, direction) {
        var cards = row.querySelectorAll('.superwoo-cross-sell');
        var rowLeft = row.getBoundingClientRect().left;
        var current = row.scrollLeft;
        var maxScrollLeft = Math.max(0, row.scrollWidth - row.clientWidth);
        var target = direction > 0 ? maxScrollLeft : 0;
        var i;
        var cardLeft;

        if (!cards.length || maxScrollLeft <= 1) {
            return;
        }

        // Use the actual card positions: card widths and gaps may vary with
        // viewport size or styles supplied by the active theme.
        if (direction > 0) {
            for (i = 0; i < cards.length; i += 1) {
                cardLeft = current + cards[i].getBoundingClientRect().left - rowLeft;
                if (cardLeft > current + 2) {
                    target = cardLeft;
                    break;
                }
            }
        } else {
            for (i = cards.length - 1; i >= 0; i -= 1) {
                cardLeft = current + cards[i].getBoundingClientRect().left - rowLeft;
                if (cardLeft < current - 2) {
                    target = cardLeft;
                    break;
                }
            }
        }

        target = Math.max(0, Math.min(maxScrollLeft, target));
        row.scrollLeft = target;
    }

    function updateCrossSellNavigation(section) {
        var row = section.querySelector('.superwoo-cross-sells__row');
        var controls = section.querySelector('.superwoo-cross-sells__controls');
        var maxScrollLeft;

        if (!row || !controls || !row.clientWidth) {
            return;
        }

        maxScrollLeft = Math.max(0, row.scrollWidth - row.clientWidth);
        controls.hidden = maxScrollLeft <= 1;
        controls.querySelector('[data-superwoo-cross-sell-nav="previous"]').disabled = row.scrollLeft <= 1;
        controls.querySelector('[data-superwoo-cross-sell-nav="next"]').disabled = row.scrollLeft >= maxScrollLeft - 1;
    }

    function syncCrossSellNavigation() {
        shell().find('.superwoo-cross-sells').each(function () {
            var section = this;
            var row = section.querySelector('.superwoo-cross-sells__row');

            if (row && !row.dataset.superwooCrossSellNavBound) {
                row.dataset.superwooCrossSellNavBound = '1';
                row.addEventListener('scroll', function () {
                    updateCrossSellNavigation(section);
                }, { passive: true });
            }

            updateCrossSellNavigation(section);
        });
    }

    function showCart() {
        var $shell = shell();
        if (!$shell.length) {
            return;
        }

        lastFocus = document.activeElement;
        $shell.addClass('is-open').attr('aria-hidden', 'false');
        $('body').addClass('superwoo-cart-open');
        window.setTimeout(function () {
            drawer().trigger('focus');
            syncCrossSellNavigation();
        }, 20);
    }

    var restoringBuyNowCart = false;

    function openCart() {
        var pending = false;
        try {
            pending = window.sessionStorage.getItem('superwoo_buy_now_pending') === '1';
        } catch (error) {
            pending = false;
        }

        if (!pending) {
            showCart();
            return;
        }
        if (restoringBuyNowCart) {
            return;
        }
        restoringBuyNowCart = true;
        refreshDrawerAfterStoreApiChange()
            .done(function (response) {
                if (!response || !response.success) {
                    return;
                }
                try {
                    window.sessionStorage.removeItem('superwoo_buy_now_pending');
                } catch (error) {
                    // The server has restored the cart regardless.
                }
                showCart();
            })
            .always(function () {
                restoringBuyNowCart = false;
            });
    }

    function closeCart() {
        var $shell = shell();
        $shell.removeClass('is-open').attr('aria-hidden', 'true');
        $('body').removeClass('superwoo-cart-open');

        if (lastFocus && typeof lastFocus.focus === 'function') {
            lastFocus.focus();
        }
    }

    function mobileSearchSheet() {
        return $('[data-superwoo-mobile-search-sheet]').first();
    }

    function focusMobileSearchInput() {
        var $input = $('[data-superwoo-mobile-search-input]').first();

        if ($input.length) {
            $input.trigger('focus');
        }
    }

    function openMobileSearch() {
        var $sheet;

        $sheet = mobileSearchSheet();
        $sheet.addClass('is-open').attr('aria-hidden', 'false');
        $('body').addClass('superwoo-mobile-search-open');
        window.setTimeout(focusMobileSearchInput, 80);
    }

    function closeMobileSearch() {
        mobileSearchSheet().removeClass('is-open').attr('aria-hidden', 'true');
        $('body').removeClass('superwoo-mobile-search-open');
    }

    function replaceFragments(fragments, preserveCrossSells) {
        if (!fragments) {
            return;
        }

        var drawerInner = fragments['.superwoo-cart-drawer__inner'] || null;

        $.each(fragments, function (selector, html) {
            if (selector === '.superwoo-cart-drawer__inner') {
                return;
            }

            $(selector).replaceWith(html);
        });

        if (drawerInner) {
            var $drawer = drawer();
            var $inner = $drawer.find('.superwoo-cart-drawer__inner').first();
            var $replacement = $(drawerInner).filter('.superwoo-cart-drawer__inner').first();
            var $oldScroll = $inner.find('[data-superwoo-cart-scroll]').first();
            var scrollTop = $oldScroll.scrollTop();
            var $recommendations = preserveCrossSells ? $inner.find('.superwoo-cross-sells').first().detach() : $();

            if ($replacement.length) {
                if ($recommendations.length) {
                    $replacement.find('[data-superwoo-cart-scroll]').first().append($recommendations);
                }
                if ($inner.length) {
                    $inner.replaceWith($replacement);
                } else {
                    $drawer.html($replacement);
                }
            } else if ($inner.length) {
                $inner.html(drawerInner);
            } else {
                $drawer.html('<div class="superwoo-cart-drawer__inner">' + drawerInner + '</div>');
            }
            $drawer.find('[data-superwoo-cart-scroll]').first().scrollTop(scrollTop);
        }

        syncCartTriggerBadges();
        syncCrossSellNavigation();
        applyingOwnCartFragments = true;
        try {
            $(document.body).trigger('wc_fragments_refreshed');
        } finally {
            applyingOwnCartFragments = false;
        }
    }

    function ajaxWithNonceRetry(action, data, url) {
        var request = $.Deferred();

        function attempt(retried) {
            $.ajax({ url: url, method: 'POST', data: data, cache: false })
                .done(function (response) {
                    request.resolve(response);
                })
                .fail(function (xhr, status, error) {
                    var response = xhr && xhr.responseJSON;
                    var invalidNonce = xhr && xhr.status === 403 && response && response.data && response.data.code === 'superwoo_invalid_nonce';

                    if (retried || !invalidNonce || !SuperWooCart.ajaxUrl) {
                        request.reject(xhr, status, error);
                        return;
                    }

                    $.ajax({
                        url: SuperWooCart.ajaxUrl,
                        method: 'POST',
                        data: { action: 'superwoo_refresh_cart_nonce', _: Date.now() },
                        cache: false
                    }).done(function (nonceResponse) {
                        if (!nonceResponse || !nonceResponse.success || !nonceResponse.data || !nonceResponse.data.nonce) {
                            request.reject(xhr, status, error);
                            return;
                        }
                        SuperWooCart.nonce = nonceResponse.data.nonce;
                        data.nonce = SuperWooCart.nonce;
                        data.security = SuperWooCart.nonce;
                        data._ = Date.now();
                        attempt(true);
                    }).fail(function () {
                        request.reject(xhr, status, error);
                    });
                });
        }

        attempt(false);
        return request.promise();
    }

    // WooCommerce stores a whole cart per session. Two overlapping cart writes
    // can save in the opposite order and make the newer click appear lost.
    var cartRequestTail = $.Deferred().resolve().promise();

    function enqueueCartRequest(action, data, url) {
        var result = $.Deferred();
        var previous = cartRequestTail;
        cartRequestTail = result.promise();

        previous.always(function () {
            data.nonce = SuperWooCart.nonce;
            data.security = SuperWooCart.nonce;
            ajaxWithNonceRetry(action, data, url)
                .done(function (response) { result.resolve(response); })
                .fail(function (xhr, status, error) { result.reject(xhr, status, error); });
        });

        return result.promise();
    }

    function post(action, data, $item, options) {
        options = options || {};
        data = data || {};
        if (action) {
            data.action = action;
        }
        data.nonce = SuperWooCart.nonce;
        data.security = SuperWooCart.nonce;
        data._ = Date.now();

        if ($item && $item.length) {
            $item.addClass('is-loading');
        }

        announce(SuperWooCart.i18n.updating);
        showCartError('');

        var cartEndpoint = SuperWooCart.wcAjaxUrls && SuperWooCart.wcAjaxUrls[action];
        return enqueueCartRequest(action, data, options.url || cartEndpoint || SuperWooCart.ajaxUrl)
            .done(function (response) {
                if (response && response.success && response.data) {
                    replaceFragments(response.data.fragments, !!response.data.preserveCrossSells);
                    syncProductQuantityFromDrawer();
                    syncOfferState(response.data.offerState, showOfferEvents(response.data.offerEvents));
                    if (typeof response.data.count !== 'undefined') {
                        setCartCount(response.data.count);
                    }
                    if (options.refreshWooFragments) {
                        $(document.body).trigger('wc_fragment_refresh');
                    }
                    if (options.openCart) {
                        openCart();
                    }
                    if (options.expectedQuantity && parseInt(response.data.updatedQuantity, 10) !== options.expectedQuantity) {
                        showCartError(SuperWooCart.i18n.quantityNotSaved);
                        announce(SuperWooCart.i18n.quantityNotSaved);
                    } else {
                        announce('');
                    }
                } else {
                    var message = response && response.data && response.data.message ? response.data.message : SuperWooCart.i18n.error;
                    showCartError(message);
                    announce(message);
                }
            })
            .fail(function (xhr) {
                var message = xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message
                    ? xhr.responseJSON.data.message : SuperWooCart.i18n.error;
                showCartError(message);
                announce(message);
            })
            .always(function () {
                if ($item && $item.length) {
                    $item.removeClass('is-loading');
                }
            });
    }

    function serializeForm($form, $button) {
        var data = {};
        var $quantity = $form.find('input.qty[name="quantity"]:enabled, input[name="quantity"]:enabled').first();
        var quantity = 1;

        $.each($form.serializeArray(), function (_index, field) {
            data[field.name] = field.value;
        });

        if ($button && $button.length && $button.attr('name')) {
            data[$button.attr('name')] = $button.val();
        }

        if (!data.product_id) {
            data.product_id = $form.find('input[name="product_id"]').val() || $form.find('[name="add-to-cart"]').val() || $button.val() || 0;
        }

        quantity = parseInt($quantity.length ? $quantity.val() : (data.quantity || 1), 10) || 1;
        data.quantity = Math.max(1, quantity);

        return data;
    }

    function productAddKey(data) {
        var parts = [
            data.product_id || 0,
            data.variation_id || 0,
            data.quantity || 1
        ];

        $.each(data, function (name, value) {
            if (name.indexOf('attribute_') === 0) {
                parts.push(name + '=' + value);
            }
        });

        return parts.join('|');
    }

    function productAddActionId(key) {
        var now = Date.now();
        var action = window.SuperWooCart && SuperWooCart._superwooProductAddAction;

        if (action && action.key === key && now - action.at < 2500) {
            return action.id;
        }

        action = {
            at: now,
            id: 'sw-' + now + '-' + Math.random().toString(36).slice(2, 12),
            key: key
        };

        if (window.SuperWooCart) {
            SuperWooCart._superwooProductAddAction = action;
        }

        return action.id;
    }

    function shouldBlockDuplicateProductAdd($form, key) {
        var now = Date.now();
        var formKey = $form.data('superwoo-last-add-key') || '';
        var formAt = parseInt($form.data('superwoo-last-add-at'), 10) || 0;

        if (productAddInFlight || $form.data('superwoo-submitting')) {
            return true;
        }

        if (key && key === lastProductAddKey && now - lastProductAddAt < 1400) {
            return true;
        }

        if (key && key === formKey && now - formAt < 1400) {
            return true;
        }

        return false;
    }

    function rememberProductAdd($form, key) {
        lastProductAddKey = key;
        lastProductAddAt = Date.now();
        $form.data('superwoo-last-add-key', key);
        $form.data('superwoo-last-add-at', lastProductAddAt);
    }

    function canAjaxSubmitProductForm($form) {
        if (!$form.length || !$form.closest('.product').length) {
            return false;
        }

        if ($form.hasClass('grouped_form') || $form.find('.group_table').length) {
            return false;
        }

        if ($form.closest('.product').find('.product_type_external').length) {
            return false;
        }

        return true;
    }

    function setProductButtonPending($button, isPending) {
        var node;
        var rect;
        var oldStyles;

        if (!$button || !$button.length) {
            return;
        }

        node = $button.get(0);
        oldStyles = $button.data('superwoo-old-product-button-style');

        if (isPending) {
            if (!oldStyles) {
                rect = node.getBoundingClientRect ? node.getBoundingClientRect() : null;
                oldStyles = {
                    ariaDisabled: $button.attr('aria-disabled') || '',
                    html: $button.is('input') ? '' : $button.html(),
                    pointerEvents: node.style.pointerEvents || '',
                    value: $button.is('input') ? $button.val() : '',
                    width: node.style.width || '',
                    minWidth: node.style.minWidth || '',
                    maxWidth: node.style.maxWidth || '',
                    flex: node.style.flex || '',
                    flexBasis: node.style.flexBasis || ''
                };

                $button.data('superwoo-old-product-button-style', oldStyles);

                if (rect && rect.width > 0 && !isMobileProductView()) {
                    node.style.setProperty('width', rect.width + 'px', 'important');
                    node.style.setProperty('min-width', rect.width + 'px', 'important');
                    node.style.setProperty('max-width', rect.width + 'px', 'important');
                    node.style.setProperty('flex', '0 0 ' + rect.width + 'px', 'important');
                    node.style.setProperty('flex-basis', rect.width + 'px', 'important');
                }
            }

            $button.attr('aria-disabled', 'true').addClass('superwoo-product-adding');
            if ($button.is('input')) {
                $button.val('');
            } else {
                $button.html('<span class="superwoo-product-spinner" aria-hidden="true"></span>');
            }
            node.style.setProperty('pointer-events', 'none', 'important');
            return;
        }

        $button.removeClass('superwoo-product-adding');

        if (oldStyles) {
            if (oldStyles.ariaDisabled) {
                $button.attr('aria-disabled', oldStyles.ariaDisabled);
            } else {
                $button.removeAttr('aria-disabled');
            }

            node.style.pointerEvents = oldStyles.pointerEvents;
            if ($button.is('input')) {
                $button.val(oldStyles.value);
            } else {
                $button.html(oldStyles.html);
            }
            node.style.width = oldStyles.width;
            node.style.minWidth = oldStyles.minWidth;
            node.style.maxWidth = oldStyles.maxWidth;
            node.style.flex = oldStyles.flex;
            node.style.flexBasis = oldStyles.flexBasis;
            $button.removeData('superwoo-old-product-button-style');
        } else {
            node.style.removeProperty('pointer-events');
        }
    }

    function ajaxSubmitProductForm($form, $button) {
        var data = serializeForm($form, $button);
        var isInitialAdd = !$form.hasClass('superwoo-product-quantity-active');
        var key = productAddKey(data);
        var request;

        // The first Add to Cart click always represents one unit. Elementor,
        // variation plugins, and restored browser form state can leave a stale
        // value in the native quantity input; quantity changes after the add
        // are handled exclusively by SuperWoo's inline controls.
        if (isInitialAdd) {
            data.quantity = 1;
            key = productAddKey(data);
        }

        if (shouldBlockDuplicateProductAdd($form, key)) {
            return true;
        }

        if ($form.hasClass('variations_form') && (!data.variation_id || parseInt(data.variation_id, 10) < 1)) {
            return false;
        }

        productAddInFlight = true;
        $form.data('superwoo-submitting', true);
        rememberProductAdd($form, key);
        data.superwoo_action_id = productAddActionId(key);
        setProductButtonPending($button, true);

        request = post('superwoo_add_product_to_cart', data, null, {
            openCart: false,
            refreshWooFragments: false
        });

        request.done(function (response) {
            if (!response || !response.success || !response.data) {
                return;
            }

            activateInlineProductQuantity($form);
            $(document.body).trigger('added_to_cart', [response.data.fragments || {}, response.data.cart_hash || '', $button]);
        }).always(function () {
            productAddInFlight = false;
            $form.removeData('superwoo-submitting');
            setProductButtonPending($button, false);
        });

        return true;
    }

    function isMobileProductView() {
        return document.body && document.body.classList.contains('single-product') && window.matchMedia('(max-width: 767px)').matches;
    }

    function productCartForm() {
        return $('body.single-product form.cart').first();
    }

    function buyNowSelectors() {
        return [
            '.buy-now',
            '.buy_now',
            '.single_buy_now_button',
            '.single-buynow-button',
            '.wd-buy-now-btn',
            '.woodmart-buy-now-btn',
            '#btn-1cc-pdp',
            '.xoo-wsc-ft-btn-checkout',
            'button[name="buy_now"]',
            'button[name="buy-now"]',
            'button[value="buy_now"]',
            'button[value="buy-now"]',
            'a[href*="buy-now"]'
        ];
    }

    function isBuyNowControl(element) {
        var label;

        if (!element || !element.matches) {
            return false;
        }

        if (element.matches(buyNowSelectors().join(','))) {
            return true;
        }

        if (!/^(button|a|input)$/i.test(element.tagName)) {
            return false;
        }

        label = ($(element).is('input') ? $(element).val() : $(element).text()) || '';
        return /^buy\s*now\b/i.test($.trim(label));
    }

    function isNativeAddToCartControl(element) {
        var $element = $(element);
        var label;

        if (!element || !element.matches || isBuyNowControl(element)) {
            return false;
        }

        if ($element.is('[data-superwoo-sticky-add-to-cart], [data-superwoo-mobile-buy-now] *')) {
            return false;
        }

        if ($element.is('button[name="add-to-cart"], input[name="add-to-cart"], button.single_add_to_cart_button')) {
            return true;
        }

        label = ($element.is('input') ? $element.val() : $element.text()) || '';
        return /^add\s*to\s*cart\b/i.test($.trim(label));
    }

    function forceMobileBuyNowLayout(element) {
        var parent;

        if (!element || !element.style) {
            return;
        }

        element.style.setProperty('box-sizing', 'border-box', 'important');
        element.style.setProperty('display', 'flex', 'important');
        element.style.setProperty('float', 'none', 'important');
        element.style.setProperty('justify-content', 'center', 'important');
        element.style.setProperty('margin', '0 0 10px', 'important');
        element.style.setProperty('max-width', '100%', 'important');
        element.style.setProperty('min-width', '0', 'important');
        element.style.setProperty('text-align', 'center', 'important');
        element.style.setProperty('width', '100%', 'important');

        parent = element.parentElement;
        if (parent && parent.style && !(parent.matches && parent.matches('form.cart'))) {
            parent.style.setProperty('box-sizing', 'border-box', 'important');
            parent.style.setProperty('display', 'block', 'important');
            parent.style.setProperty('float', 'none', 'important');
            parent.style.setProperty('margin', '0 0 10px', 'important');
            parent.style.setProperty('max-width', '100%', 'important');
            parent.style.setProperty('width', '100%', 'important');
        }
    }

    function forceInlineCartGrid($form) {
        var form = $form && $form.length ? $form.get(0) : null;
        var $layout;
        var $variationWrap;
        var $quantity;
        var $addToCart;
        var $buyNow;
        var isVariationForm;

        if (!form || !isMobileProductView()) {
            return;
        }

        isVariationForm = $form.hasClass('variations_form');

        form.style.setProperty('box-sizing', 'border-box', 'important');
        form.style.setProperty('float', 'none', 'important');
        form.style.setProperty('margin', '0 0 10px', 'important');
        form.style.setProperty('max-width', '100%', 'important');
        form.style.setProperty('width', '100%', 'important');

        if (isVariationForm) {
            form.style.setProperty('display', 'block', 'important');
            form.style.removeProperty('gap');
            form.style.removeProperty('grid-auto-flow');
            form.style.removeProperty('grid-template-columns');
        } else {
            form.style.setProperty('display', 'grid', 'important');
            form.style.setProperty('gap', '10px', 'important');
            form.style.setProperty('grid-auto-flow', 'row', 'important');
            form.style.setProperty('grid-template-columns', 'repeat(2, minmax(0, 1fr))', 'important');
        }

        $layout = $form.find('.woocommerce-variation-add-to-cart').first();
        if ($layout.length) {
            $layout.get(0).style.setProperty('display', 'grid', 'important');
            $layout.get(0).style.setProperty('gap', '10px', 'important');
            $layout.get(0).style.setProperty('grid-auto-flow', 'row', 'important');
            $layout.get(0).style.setProperty('grid-template-columns', 'repeat(2, minmax(0, 1fr))', 'important');
            $layout.get(0).style.setProperty('width', '100%', 'important');
        }

        $variationWrap = $form.find('.single_variation_wrap').first();
        if ($variationWrap.length) {
            $variationWrap.get(0).style.setProperty('display', 'block', 'important');
            $variationWrap.get(0).style.setProperty('margin', '0', 'important');
            $variationWrap.get(0).style.setProperty('max-width', '100%', 'important');
            $variationWrap.get(0).style.setProperty('width', '100%', 'important');
            $variationWrap.get(0).style.removeProperty('gap');
            $variationWrap.get(0).style.removeProperty('grid-auto-flow');
            $variationWrap.get(0).style.removeProperty('grid-template-columns');
        }

        $quantity = $form.find('.quantity').first();
        if ($quantity.length) {
            $quantity.get(0).style.setProperty('align-items', 'stretch', 'important');
            $quantity.get(0).style.setProperty('display', $form.hasClass('superwoo-product-quantity-active') ? 'grid' : 'none', 'important');
            $quantity.get(0).style.setProperty('grid-column', '1', 'important');
            $quantity.get(0).style.setProperty('grid-row', '1', 'important');
            $quantity.get(0).style.setProperty('grid-template-columns', '1fr 1fr 1fr', 'important');
            $quantity.get(0).style.setProperty('margin', '0', 'important');
            $quantity.get(0).style.setProperty('min-width', '0', 'important');
            $quantity.get(0).style.setProperty('overflow', 'visible', 'important');
            $quantity.get(0).style.setProperty('width', '100%', 'important');

            $quantity.find('.qty-btn, button, input.qty, input[name="quantity"]').each(function () {
                this.style.setProperty('align-items', 'center', 'important');
                this.style.setProperty('box-sizing', 'border-box', 'important');
                this.style.setProperty('display', 'inline-flex', 'important');
                this.style.setProperty('justify-content', 'center', 'important');
                this.style.setProperty('margin', '0', 'important');
                this.style.setProperty('min-width', '0', 'important');
                this.style.setProperty('opacity', '1', 'important');
                this.style.setProperty('padding-left', '0', 'important');
                this.style.setProperty('padding-right', '0', 'important');
                this.style.setProperty('visibility', 'visible', 'important');
                this.style.setProperty('width', '100%', 'important');
            });
        }

        $addToCart = nativeAddToCartButton($form);
        if ($addToCart.length) {
            $addToCart.get(0).style.setProperty('display', $form.hasClass('superwoo-product-quantity-active') ? 'none' : 'inline-flex', 'important');
            $addToCart.get(0).style.setProperty('grid-column', '1', 'important');
            $addToCart.get(0).style.setProperty('grid-row', '1', 'important');
            $addToCart.get(0).style.setProperty('justify-content', 'center', 'important');
            $addToCart.get(0).style.setProperty('margin', '0', 'important');
            $addToCart.get(0).style.setProperty('width', '100%', 'important');
        }

        $buyNow = $form.find('.superwoo-native-buy-now-mobile').first();
        if ($buyNow.length) {
            $buyNow.get(0).style.setProperty('display', 'flex', 'important');
            $buyNow.get(0).style.setProperty('grid-column', '2', 'important');
            $buyNow.get(0).style.setProperty('grid-row', '1', 'important');
            $buyNow.get(0).style.setProperty('justify-content', 'center', 'important');
            $buyNow.get(0).style.setProperty('margin', '0', 'important');
            $buyNow.get(0).style.setProperty('width', '100%', 'important');
        }
    }

    function auditMobileProductButtons($form) {
        var $scope = $form.closest('.product, .summary, .elementor-widget-woocommerce-product-add-to-cart, .elementor-section, .elementor-container').first();
        var $controls = $form.find('button, input[type="submit"], input[type="button"], a');

        if ($scope.length) {
            $controls = $controls.add($scope.find('button, input[type="submit"], input[type="button"], a'));
        }

        $controls.each(function () {
            var $control = $(this);

            $control.removeClass('superwoo-native-add-to-cart-mobile superwoo-native-buy-now-mobile');
            $control.parent().removeClass('superwoo-native-buy-now-wrap-mobile');

            if (isBuyNowControl(this)) {
                $control.addClass('superwoo-native-buy-now-mobile');
                if (!$control.parent().is('form.cart')) {
                    $control.parent().addClass('superwoo-native-buy-now-wrap-mobile');
                }
                this.style.removeProperty('visibility');
                this.style.removeProperty('opacity');
                forceMobileBuyNowLayout(this);
                return;
            }

            if (isNativeAddToCartControl(this)) {
                $control.addClass('superwoo-native-add-to-cart-mobile');
            }
        });

        forceInlineCartGrid($form);
    }

    function activateInlineProductQuantity($form) {
        if (!$form || !$form.length) {
            return;
        }

        $form.addClass('superwoo-product-quantity-active');
        forceInlineCartGrid($form);
    }

    function prepareInlineProductActions() {
        var $form = productCartForm();

        if (!$form.length || $form.hasClass('grouped_form')) {
            return;
        }

        $form.addClass('superwoo-product-actions-ready');
        $form.find('.single_add_to_cart_button').each(function () {
            $(this).toggleClass('superwoo-inline-buy-now', isBuyNowControl(this));
        });

        normalizeProductQuantityControls($form);
        observeProductQuantityControls($form);
    }

    function quantityControlDirection(element) {
        var text = $.trim(($(element).is('input') ? $(element).val() : $(element).text()) || '');

        if (/^[\-−–—]$/.test(text)) {
            return 'minus';
        }
        if (text === '+') {
            return 'plus';
        }
        return '';
    }

    function normalizeProductQuantityControls($form) {
        var $quantity = $form.find('.quantity').first();
        var controls = { minus: [], plus: [] };
        var keep;

        if (!$quantity.length) {
            return;
        }

        $form.find('button, input[type="button"], a, [role="button"], .minus, .plus').each(function () {
            var direction;

            if (isNativeAddToCartControl(this) || isBuyNowControl(this)) {
                return;
            }

            direction = quantityControlDirection(this);
            if (direction) {
                controls[direction].push(this);
            }
        });

        $.each(['minus', 'plus'], function (_index, direction) {
            keep = controls[direction].filter(function (element) {
                return $(element).is('[data-superwoo-product-qty-' + direction + ']');
            })[0] || controls[direction][0];

            $.each(controls[direction], function (_controlIndex, element) {
                if (element !== keep) {
                    $(element).remove();
                }
            });

            if (!keep) {
                keep = $('<button type="button" class="qty-btn" data-superwoo-product-qty-' + direction + '="" aria-label="' + (direction === 'minus' ? 'Decrease' : 'Increase') + ' quantity">' + (direction === 'minus' ? '−' : '+') + '</button>').get(0);
            }

            $(keep).attr('data-superwoo-product-qty-' + direction, '');
            if (keep.parentNode !== $quantity.get(0)) {
                if (direction === 'minus') {
                    $quantity.prepend(keep);
                } else {
                    $quantity.append(keep);
                }
            }
        });
    }

    function observeProductQuantityControls($form) {
        var form = $form.get(0);

        if (!form || !window.MutationObserver) {
            return;
        }

        if (productQuantityObserver) {
            productQuantityObserver.disconnect();
        }

        productQuantityObserver = new MutationObserver(function () {
            window.clearTimeout(productQuantityNormalizeTimer);
            productQuantityNormalizeTimer = window.setTimeout(function () {
                normalizeProductQuantityControls($form);
            }, 20);
        });
        productQuantityObserver.observe(form, { childList: true, subtree: true });
    }

    function nativeAddToCartButton($form) {
        var $classified = $form.find('.superwoo-native-add-to-cart-mobile').first();

        if ($classified.length) {
            return $classified;
        }

        return $form.find('button.single_add_to_cart_button[type="submit"], button.single_add_to_cart_button, button[name="add-to-cart"], input[name="add-to-cart"]').filter(function () {
            return isNativeAddToCartControl(this);
        }).first();
    }

    function stickyBuyNowShell() {
        var $sticky = $('[data-superwoo-mobile-buy-now]').first();

        if ($sticky.length) {
            if (!$sticky.find('[data-superwoo-mobile-qty-input]').length) {
                $sticky.prepend('<div class="superwoo-mobile-buy-now__qty" aria-label="Choose quantity"><button type="button" data-superwoo-mobile-qty-minus aria-label="Decrease quantity">−</button><input type="number" min="1" step="1" value="1" data-superwoo-mobile-qty-input aria-label="Quantity"><button type="button" data-superwoo-mobile-qty-plus aria-label="Increase quantity">+</button></div>');
            }
            $sticky.find('[data-superwoo-sticky-buy-now]').attr('data-superwoo-sticky-add-to-cart', '').removeAttr('data-superwoo-sticky-buy-now');
            return $sticky;
        }

        $sticky = $('<div class="superwoo-mobile-buy-now" data-superwoo-mobile-buy-now><div class="superwoo-mobile-buy-now__qty" aria-label="Choose quantity"><button type="button" data-superwoo-mobile-qty-minus aria-label="Decrease quantity">−</button><input type="number" min="1" step="1" value="1" data-superwoo-mobile-qty-input aria-label="Quantity"><button type="button" data-superwoo-mobile-qty-plus aria-label="Increase quantity">+</button></div><button type="button" class="superwoo-mobile-buy-now__button" data-superwoo-sticky-add-to-cart>ADD TO CART</button></div>');
        $('body').append($sticky);
        return $sticky;
    }

    function productQuantityInput($form) {
        return $form.find('input.qty[name="quantity"], input[name="quantity"]').first();
    }

    function productIdentity($form) {
        $form = $form && $form.jquery ? $form : $($form);
        if (!$form.length) {
            return { productId: 0, variationId: 0 };
        }

        var $button = nativeAddToCartButton($form);
        var data = serializeForm($form, $button);

        return {
            productId: parseInt(data.product_id, 10) || 0,
            variationId: parseInt(data.variation_id, 10) || 0
        };
    }

    function matchingDrawerItemsForProductForm($form) {
        $form = $form && $form.jquery ? $form : $($form);
        var identity = productIdentity($form);

        if (!identity.productId) {
            return $();
        }

        return $('.superwoo-cart-item[data-product-id="' + identity.productId + '"][data-variation-id="' + identity.variationId + '"]');
    }

    function syncProductQuantityFromDrawer() {
        var $form = productCartForm();
        var $input;
        var $items;
        var quantity = 0;

        if (!$form.length) {
            return;
        }

        $input = productQuantityInput($form);
        $items = matchingDrawerItemsForProductForm($form);
        $items.each(function () {
            quantity += parseInt($(this).find('[data-superwoo-qty-input]').val(), 10) || 0;
        });

        if (quantity > 0) {
            $input.val(quantity).trigger('input').trigger('change');
            activateInlineProductQuantity($form);
            return;
        }

        $input.val(1).trigger('input').trigger('change');
        $form.removeClass('superwoo-product-quantity-active');
        forceInlineCartGrid($form);
    }

    function syncStickyQuantity($form, $sticky) {
        var $formQty = productQuantityInput($form);
        var $stickyQty = $sticky.find('[data-superwoo-mobile-qty-input]').first();
        var value = parseInt($formQty.val(), 10) || parseInt($stickyQty.val(), 10) || 1;

        value = Math.max(1, value);
        $stickyQty.val(value);
        if ($formQty.length) {
            $formQty.val(value).trigger('change');
        }
    }

    function setMobileProductBarState(showSticky) {
        var $body = $('body');

        if (!isMobileProductView()) {
            $body.removeClass('superwoo-mobile-product-sticky-active');
            return;
        }

        $body.toggleClass('superwoo-mobile-product-sticky-active', !!showSticky);
    }

    function observeOriginalProductCart($form) {
        var form = $form.get(0);
        var addButton = nativeAddToCartButton($form).get(0);
        var target = addButton || form;

        if (!target || !window.IntersectionObserver) {
            setMobileProductBarState(false);
            return;
        }

        if (observedProductCartForm === target && productCartVisibilityObserver) {
            return;
        }

        if (productCartVisibilityObserver) {
            productCartVisibilityObserver.disconnect();
        }

        // The form can include variation selectors and other content. Observe
        // the real native add control so the state changes immediately after
        // the original Add to Cart section has scrolled above the viewport.
        observedProductCartForm = target;
        if (target.getBoundingClientRect().bottom <= 0) {
            $form.data('superwoo-cart-form-seen', true);
        }

        productCartVisibilityObserver = new IntersectionObserver(function (entries) {
            var entry = entries[0];
            var hasBeenVisible;

            if (!entry || !isMobileProductView()) {
                setMobileProductBarState(false);
                return;
            }

            hasBeenVisible = $form.data('superwoo-cart-form-seen') === true;
            if (entry.isIntersecting) {
                $form.data('superwoo-cart-form-seen', true);
                setMobileProductBarState(false);
                return;
            }

            setMobileProductBarState(hasBeenVisible && entry.boundingClientRect.bottom <= 0);
        }, {
            threshold: 0
        });

        productCartVisibilityObserver.observe(target);
    }

    function setStickyQuantity(value) {
        var $form = productCartForm();
        var $sticky = stickyBuyNowShell();
        var next = Math.max(1, parseInt(value, 10) || 1);

        $sticky.find('[data-superwoo-mobile-qty-input]').val(next);
        productQuantityInput($form).val(next).trigger('change');
    }

    function syncStickyBuyNow() {
        var $form = productCartForm();
        var $existingSticky = $('[data-superwoo-mobile-buy-now]').first();
        var $sticky;
        var $button;
        var $addToCart;
        var disabled = false;

        // This is display-only. Do not require SuperWoo's former custom-AJAX
        // eligibility before showing a sticky control for a native WC form.
        if (!isMobileProductView() || !$form.length || !nativeAddToCartButton($form).length) {
            $existingSticky.hide();
            $('body').removeClass('superwoo-has-mobile-buy-now superwoo-mobile-product-sticky-active');
            if (productCartVisibilityObserver) {
                productCartVisibilityObserver.disconnect();
                productCartVisibilityObserver = null;
                observedProductCartForm = null;
            }
            return;
        }

        auditMobileProductButtons($form);
        $sticky = stickyBuyNowShell();
        $button = $sticky.find('[data-superwoo-sticky-add-to-cart]').first();
        $addToCart = nativeAddToCartButton($form);

        if ($addToCart.length) {
            disabled = $addToCart.is(':disabled') || $addToCart.hasClass('disabled') || $addToCart.attr('aria-disabled') === 'true';
        }

        syncStickyQuantity($form, $sticky);
        syncStickyButtonColors($button, $addToCart);
        forceInlineCartGrid($form);
        $button.text('ADD TO CART').prop('disabled', disabled).toggleClass('is-disabled', disabled);
        $sticky.css('display', '');
        $('body').addClass('superwoo-has-mobile-buy-now');
        observeOriginalProductCart($form);
    }

    function syncStickyButtonColors($button, $source) {
        var source = $source && $source.length ? $source.get(0) : null;
        var sticky = $button && $button.length ? $button.get(0) : null;
        var style;
        var background;
        var color;

        if (!source || !sticky || !window.getComputedStyle) {
            return;
        }

        style = window.getComputedStyle(source);
        background = style.backgroundColor;
        color = style.color;

        if (background && background !== 'transparent' && !/^rgba\(\s*0\s*,\s*0\s*,\s*0\s*,\s*0\s*\)$/i.test(background)) {
            sticky.style.setProperty('--superwoo-mobile-atc-bg', background);
        }

        if (color) {
            sticky.style.setProperty('--superwoo-mobile-atc-text', color);
        }
    }

    function scheduleStickyBuyNowSync() {
        window.clearTimeout(stickyBuyNowTimer);
        stickyBuyNowTimer = window.setTimeout(syncStickyBuyNow, 60);
    }

    function clickStickyBuyNow(event) {
        var $form = productCartForm();
        var $addToCart;

        event.preventDefault();
        event.stopPropagation();

        if (!$form.length) {
            return;
        }

        auditMobileProductButtons($form);
        $addToCart = nativeAddToCartButton($form);

        if (!$addToCart.length) {
            return;
        }

        if (!ajaxSubmitProductForm($form, $addToCart)) {
            announce(SuperWooCart.i18n.chooseOptions);
        }
    }

    var quantityEdits = {};

    function cartItemByKey(key) {
        return shell().find('.superwoo-cart-item').filter(function () {
            return $(this).attr('data-cart-item-key') === key;
        }).first();
    }

    function finishQuantityEdit(key, confirmed) {
        var $item = cartItemByKey(key);
        if ($item.length) {
            $item.removeClass('is-loading');
            $item.find('[data-superwoo-qty-input]').val(confirmed);
        }
        delete quantityEdits[key];
    }

    function sendQuantityEdit(key) {
        var state = quantityEdits[key];
        var sent;
        if (!state || state.inFlight) {
            return;
        }
        if (state.desired === state.confirmed) {
            finishQuantityEdit(key, state.confirmed);
            return;
        }

        sent = state.desired;
        state.inFlight = true;
        post('superwoo_update_cart_item', {
            cart_item_key: key,
            quantity: sent
        }, null, { expectedQuantity: sent }).done(function (response) {
            var updated = response && response.success && response.data
                ? parseInt(response.data.updatedQuantity, 10) : NaN;
            var $current;

            if (updated !== sent) {
                if (state.removeAfter) {
                    delete quantityEdits[key];
                    removeItem(cartItemByKey(key));
                } else {
                    finishQuantityEdit(key, !isNaN(updated) && updated > 0 ? updated : state.confirmed);
                }
                return;
            }
            state.confirmed = sent;
            state.inFlight = false;
            $current = cartItemByKey(key);
            if (state.removeAfter) {
                delete quantityEdits[key];
                removeItem($current);
            } else if (state.desired !== state.confirmed && $current.length) {
                $current.addClass('is-loading');
                $current.find('[data-superwoo-qty-input]').val(state.desired);
                sendQuantityEdit(key);
            } else {
                finishQuantityEdit(key, state.confirmed);
            }
        }).fail(function () {
            if (state.removeAfter) {
                delete quantityEdits[key];
                removeItem(cartItemByKey(key));
            } else {
                finishQuantityEdit(key, state.confirmed);
            }
        });
    }

    function updateItem($item, quantity) {
        var key = $item.attr('data-cart-item-key');
        var $input = $item.find('[data-superwoo-qty-input]');
        var state;
        if (!key) {
            return;
        }

        state = quantityEdits[key];
        if (!state) {
            state = {
                confirmed: parseInt($input.attr('data-superwoo-qty-committed'), 10)
                    || parseInt($input.prop('defaultValue'), 10) || 1,
                desired: 0,
                inFlight: false,
                timer: null,
                removeAfter: false
            };
            quantityEdits[key] = state;
        }

        state.desired = Math.max(1, parseInt(quantity, 10) || 1);
        $input.val(state.desired);
        $item.addClass('is-loading');
        if (!state.inFlight) {
            window.clearTimeout(state.timer);
            // Combine a short burst of clicks into one cart calculation.
            state.timer = window.setTimeout(function () { sendQuantityEdit(key); }, 35);
        }
    }

    function removeItem($item) {
        var key = $item.attr('data-cart-item-key');
        var state = key && quantityEdits[key];
        if (!key) {
            return;
        }
        if (state) {
            window.clearTimeout(state.timer);
            if (state.inFlight) {
                state.removeAfter = true;
                $item.addClass('is-removing');
                return;
            }
            delete quantityEdits[key];
        }
        $item.addClass('is-removing');
        post('superwoo_remove_cart_item', { cart_item_key: key }, $item).fail(function () {
            $item.removeClass('is-removing');
        });
    }

    $(document).on('click', '[data-superwoo-open-cart]', function (event) {
        event.preventDefault();
        openCart();
    });

    $(document).on('click', '[data-superwoo-open-mobile-search]', function (event) {
        event.preventDefault();
        openMobileSearch();
    });

    $(document).on('click', '[data-superwoo-close-mobile-search]', function (event) {
        event.preventDefault();
        closeMobileSearch();
    });

    $(document).on('click', 'a[href], [data-superwoo-cart-trigger]', function (event) {
        if (!isCartTriggerLink(this)) {
            return;
        }

        event.preventDefault();
        event.stopPropagation();
        openCart();
    });

    document.addEventListener('click', function (event) {
        var trigger = closestCartTrigger(event.target);

        if (!trigger || !isCartTriggerLink(trigger)) {
            return;
        }

        event.preventDefault();
        event.stopPropagation();
        openCart();
    }, true);

    $(document).on('click', '[data-superwoo-close-cart]', function (event) {
        event.preventDefault();
        closeCart();
    });

    $(document).on('click.superwooCartOutside', function (event) {
        var $shell = shell();
        var drawerNode = drawer().get(0);

        if (!$shell.hasClass('is-open') || !drawerNode) {
            return;
        }

        // Keep all drawer controls interactive and do not immediately close
        // the drawer when the click that opened it reaches the document.
        if (drawerNode.contains(event.target) || closestCartTrigger(event.target)) {
            return;
        }

        closeCart();
    });

    $(document).on('keydown', function (event) {
        if (event.key === 'Escape' && shell().hasClass('is-open')) {
            closeCart();
        }
        if (event.key === 'Escape' && mobileSearchSheet().hasClass('is-open')) {
            closeMobileSearch();
        }
    });

    document.addEventListener('wheel', function (event) {
        var $shell = shell();
        if (!$shell.hasClass('is-open')) {
            return;
        }

        var drawerNode = drawer().get(0);
        var scroller = scrollContainer().get(0);
        if (!drawerNode || !scroller || !drawerNode.contains(event.target)) {
            return;
        }

        scroller.scrollTop += event.deltaY;
        event.preventDefault();
        event.stopPropagation();
    }, { passive: false, capture: true });

    var touchStartX = 0;
    var touchStartY = 0;
    var touchCrossSellRow = null;
    var touchDirection = '';
    document.addEventListener('touchstart', function (event) {
        if (!shell().hasClass('is-open') || !drawer().get(0) || !drawer().get(0).contains(event.target)) {
            return;
        }

        touchStartX = event.touches[0].clientX;
        touchStartY = event.touches[0].clientY;
        touchCrossSellRow = event.target.closest && event.target.closest('.superwoo-cross-sells__row');
        touchDirection = '';
    }, { passive: true, capture: true });

    document.addEventListener('touchmove', function (event) {
        var drawerNode = drawer().get(0);
        var scroller = scrollContainer().get(0);
        if (!shell().hasClass('is-open') || !drawerNode || !scroller || !drawerNode.contains(event.target)) {
            return;
        }

        var nextX = event.touches[0].clientX;
        var nextY = event.touches[0].clientY;
        if (touchCrossSellRow && touchCrossSellRow.scrollWidth > touchCrossSellRow.clientWidth) {
            if (!touchDirection && (Math.abs(nextX - touchStartX) > 5 || Math.abs(nextY - touchStartY) > 5)) {
                touchDirection = Math.abs(nextX - touchStartX) > Math.abs(nextY - touchStartY) ? 'horizontal' : 'vertical';
            }
            if (touchDirection === 'horizontal' || !touchDirection) {
                // Let the row's native touch scrolling move the cards.
                return;
            }
        }
        scroller.scrollTop += touchStartY - nextY;
        touchStartY = nextY;
        event.preventDefault();
        event.stopPropagation();
    }, { passive: false, capture: true });

    // The drawer is replaced after each response. Capture controls before
    // theme delegates can stop their clicks, and use the new row on reruns.
    document.addEventListener('click', function (event) {
        var control = event.target.closest && event.target.closest('[data-superwoo-qty-minus], [data-superwoo-qty-plus], [data-superwoo-remove-item]');
        var $item;
        var current;

        if (!control || !control.closest('[data-superwoo-cart-shell]')) {
            return;
        }

        event.preventDefault();
        event.stopPropagation();
        $item = $(control).closest('.superwoo-cart-item');
        if (!$item.length || $item.hasClass('is-removing')) {
            return;
        }

        if (control.hasAttribute('data-superwoo-remove-item')) {
            removeItem($item);
            return;
        }

        current = parseInt($item.find('[data-superwoo-qty-input]').val(), 10) || 1;
        if (control.hasAttribute('data-superwoo-qty-minus') && current <= 1) {
            removeItem($item);
            return;
        }

        updateItem($item, current + (control.hasAttribute('data-superwoo-qty-plus') ? 1 : -1));
    }, true);

    document.addEventListener('change', function (event) {
        var input = event.target.closest && event.target.closest('[data-superwoo-qty-input]');
        var $item;

        if (!input || !input.closest('[data-superwoo-cart-shell]')) {
            return;
        }

        event.stopPropagation();
        $item = $(input).closest('.superwoo-cart-item');
        if ($item.length) {
            updateItem($item, input.value);
        }
    }, true);

    $(document).on('change', '[data-superwoo-whatsapp-consent]', function () {
        var $checkbox = $(this);
        var requestedConsent = $checkbox.is(':checked');

        $checkbox.prop('disabled', true);
        post('superwoo_set_whatsapp_order_updates_consent', {
            consent: requestedConsent ? '1' : '0'
        }, $checkbox).done(function (response) {
            if (!response || !response.success) {
                $checkbox.prop('checked', !requestedConsent);
            }
        }).fail(function () {
            $checkbox.prop('checked', !requestedConsent);
        }).always(function () {
            $checkbox.prop('disabled', false);
        });
    });


    function handleSingleProductAdd(control, event) {
        var $button = $(control);
        var $form = $button.closest('body.single-product form.cart');

        if (!$form.length || !canAjaxSubmitProductForm($form) || isBuyNowControl(control) || !isNativeAddToCartControl(control)) {
            return false;
        }

        if ($button.is(':disabled, .disabled') || $button.attr('aria-disabled') === 'true') {
            return true;
        }

        if (event && event.__superwooProductAddHandled) {
            return true;
        }
        if (event) {
            event.__superwooProductAddHandled = true;
        }

        event.preventDefault();
        event.stopPropagation();
        if (event.stopImmediatePropagation) {
            event.stopImmediatePropagation();
        }

        if (!ajaxSubmitProductForm($form, $button)) {
            announce(SuperWooCart.i18n.chooseOptions);
        }

        return true;
    }

    document.addEventListener('click', function (event) {
        var control = event.target && event.target.closest ? event.target.closest('body.single-product form.cart button, body.single-product form.cart input[type="submit"]') : null;
        if (control) {
            if (isBuyNowControl(control)) {
                // Leave third-party Buy Now / checkout behavior to the owning
                // WooCommerce or payment extension.
                return;
            }
            handleSingleProductAdd(control, event);
        }
    }, true);

    document.addEventListener('submit', function (event) {
        var form = event.target;
        var $form;
        var $button;

        if (!form || !form.matches || !form.matches('body.single-product form.cart')) {
            return;
        }

        if ((event.submitter && isBuyNowControl(event.submitter))
            || (document.activeElement && isBuyNowControl(document.activeElement))) {
            return;
        }

        $form = $(form);
        $button = nativeAddToCartButton($form);
        handleSingleProductAdd($button.get(0), event);
    }, true);

    $(document).on('click', '[data-superwoo-sticky-add-to-cart]', clickStickyBuyNow);
    document.addEventListener('click', function (event) {
        var control = event.target && event.target.closest ? event.target.closest('[data-superwoo-product-qty-minus], [data-superwoo-product-qty-plus]') : null;
        var $control;
        var $input;
        var current;
        var step;
        var min;
        var max;
        var next;
        var isMinus;
        var $drawerItem;

        if (!control) {
            return;
        }

        $control = $(control);
        $input = $control.siblings('input.qty, input[name="quantity"]').first();
        if (!$input.length) {
            return;
        }

        current = parseFloat($input.val()) || 1;
        step = parseFloat($input.attr('step')) || 1;
        min = parseFloat($input.attr('min')) || 1;
        max = parseFloat($input.attr('max'));
        isMinus = $control.is('[data-superwoo-product-qty-minus]');
        next = isMinus ? current - step : current + step;
        $drawerItem = matchingDrawerItemsForProductForm($(control).closest('form.cart')).first();

        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();

        if (isMinus && current <= min) {
            if ($drawerItem.length) {
                removeItem($drawerItem);
            } else {
                $input.val(min).trigger('input').trigger('change');
                $(control).closest('form.cart').removeClass('superwoo-product-quantity-active');
                forceInlineCartGrid($(control).closest('form.cart'));
            }
            return;
        }

        next = Math.max(min, next);
        if (!isNaN(max)) {
            next = Math.min(max, next);
        }
        $input.val(next).trigger('input').trigger('change');

        if ($drawerItem.length) {
            updateItem($drawerItem, next);
        }
    }, true);
    $(document).on('submit', 'body.single-product form.cart', function () {
        // Native WooCommerce submissions normally reload the product page and
        // do not emit `added_to_cart`. Preserve the user's intent so the
        // drawer can be opened once the refreshed page is ready. A submit
        // event is used instead of a click so invalid variation/required
        // fields do not leave a stale auto-open flag behind.
        try {
            window.sessionStorage.setItem('superwoo-open-cart-after-native-product-submit', '1');
        } catch (storageError) {
            // Storage access is optional.
        }
    });
    $(document).on('click', '[data-superwoo-mobile-qty-minus]', function (event) {
        var current = parseInt(stickyBuyNowShell().find('[data-superwoo-mobile-qty-input]').val(), 10) || 1;

        event.preventDefault();
        setStickyQuantity(current - 1);
    });
    $(document).on('click', '[data-superwoo-mobile-qty-plus]', function (event) {
        var current = parseInt(stickyBuyNowShell().find('[data-superwoo-mobile-qty-input]').val(), 10) || 1;

        event.preventDefault();
        setStickyQuantity(current + 1);
    });
    $(document).on('change input', '[data-superwoo-mobile-qty-input]', function () {
        setStickyQuantity($(this).val());
    });
    $(document).on('change input', 'body.single-product form.cart input.qty[name="quantity"], body.single-product form.cart input[name="quantity"]', scheduleStickyBuyNowSync);

    $(document.body).on('found_variation reset_data woocommerce_variation_has_changed', scheduleStickyBuyNowSync);

    $(document).on('click', '[data-superwoo-add-cross-sell]', function () {
        post('superwoo_add_cross_sell', {
            product_id: $(this).data('superwoo-add-cross-sell')
        }, $(this).closest('.superwoo-cross-sell'), {
            openCart: true,
            refreshWooFragments: false
        });
    });

    // Capture the click before theme handlers can stop bubbling. The drawer
    // contents are replaced after cart changes, so bind once to document.
    document.addEventListener('click', function (event) {
        var button = event.target.closest && event.target.closest('[data-superwoo-cross-sell-nav]');
        var section = button && button.closest('.superwoo-cross-sells');
        var row = section && section.querySelector('.superwoo-cross-sells__row');
        var direction;

        if (!button) {
            return;
        }
        event.preventDefault();
        if (!row || button.disabled) {
            return;
        }

        direction = button.getAttribute('data-superwoo-cross-sell-nav') === 'previous' ? -1 : 1;
        moveCrossSellByCard(row, direction);
        updateCrossSellNavigation(section);
    }, true);

    // A vertical mouse wheel cannot move a horizontal recommendations row by
    // itself. Translate it while the pointer is over the row; touch devices
    // retain native horizontal swipe scrolling.
    $(document).on('wheel.superwooCartRecommendations', '.superwoo-cross-sells__row', function (event) {
        var originalEvent = event.originalEvent;
        var maxScrollLeft = this.scrollWidth - this.clientWidth;

        if (!originalEvent || maxScrollLeft <= 0 || Math.abs(originalEvent.deltaX) >= Math.abs(originalEvent.deltaY)) {
            return;
        }

        var nextScrollLeft = Math.max(0, Math.min(maxScrollLeft, this.scrollLeft + originalEvent.deltaY));
        if (nextScrollLeft !== this.scrollLeft) {
            this.scrollLeft = nextScrollLeft;
            event.preventDefault();
        }
    });

    $(document.body).on('added_to_cart', function () {
        activateInlineProductQuantity(productCartForm());
        try {
            window.sessionStorage.removeItem('superwoo-open-cart-after-native-product-submit');
        } catch (storageError) {
            // Storage access is optional.
        }

        window.setTimeout(function () {
            syncCartTriggerBadges();
            fetchCartCount();
        }, 100);

        // WooCommerce has already completed the add at this point. On product
        // pages the drawer should reflect that successful native cart action.
        if (SuperWooCart.autoOpen || $('body').hasClass('single-product')) {
            openCart();
        }
    });

    $(document.body).on('wc_fragments_loaded wc_fragments_refreshed removed_from_cart updated_cart_totals', function () {
        if (applyingOwnCartFragments) {
            // This response already includes the authoritative cart count.
            // Avoid another Store API request racing against its new totals.
            return;
        }
        window.setTimeout(function () {
            syncCartTriggerBadges();
            fetchCartCount();
            syncCrossSellNavigation();
        }, 20);
    });

    $(window).on('hashchange.superwooCart', function () {
        if (window.location.hash === '#superwoo-cart') {
            openCart();
        }
    });

    $(function () {
        if (suppressDashboardBottomNav()) {
            return;
        }

        if (!mobileSearchSheet().hasClass('is-open')) {
            $('body').removeClass('superwoo-mobile-search-open');
        }

        syncCartTriggerBadges();
        syncCrossSellNavigation();
        startTriggerObserver();
        fetchCartCount();
        prepareInlineProductActions();
        syncProductQuantityFromDrawer();
        syncStickyBuyNow();
        // Some product builders finish rendering the form after DOM-ready.
        // A bounded retry keeps the observer lightweight while still finding it.
        window.setTimeout(syncStickyBuyNow, 350);
        window.setTimeout(syncStickyBuyNow, 1200);
        window.setTimeout(prepareInlineProductActions, 350);
        window.setTimeout(prepareInlineProductActions, 1200);
        window.setTimeout(syncProductQuantityFromDrawer, 400);

        try {
            if (window.sessionStorage.getItem('superwoo-open-cart-after-native-product-submit') === '1') {
                window.sessionStorage.removeItem('superwoo-open-cart-after-native-product-submit');
                window.setTimeout(openCart, 220);
            }
        } catch (storageError) {
            // Storage access is optional.
        }

        if (window.location.hash === '#superwoo-cart') {
            window.setTimeout(openCart, 80);
        }
    });


    $(window).on('resize.superwooCart orientationchange.superwooCart', function () {
        scheduleStickyBuyNowSync();
        syncCrossSellNavigation();
    });


    window.SuperWooOpenCart = openCart;
})(jQuery);
